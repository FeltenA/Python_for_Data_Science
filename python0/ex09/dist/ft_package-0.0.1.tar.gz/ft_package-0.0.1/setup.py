from setuptools import setup, find_packages

setup(
    name="ft_package",
    version="0.0.1",
    description="A sample test package",
    author="afelten",
    author_email="afelten@42.fr",
    packages=find_packages(),
    licence="MIT",
    url="https://github.com/FeltenA/Python_for_Data_Science\
/python0/ex09/ft_package",
)
